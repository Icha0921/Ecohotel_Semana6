from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime
import csv
from io import StringIO

app = Flask(__name__)
app.secret_key = 'ecohotel_secret_key'
DATABASE = 'ecohotel.db'

# ...existing code...
from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'ecohotel_secret_key'

DATABASE = 'ecohotel.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    # Tabla de habitaciones
    c.execute('''CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT,
        price REAL,
        features TEXT,
        image TEXT
    )''')
    # Tabla de clientes
    c.execute('''CREATE TABLE IF NOT EXISTS clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        phone TEXT
    )''')
    # Tabla de reservas
    c.execute('''CREATE TABLE IF NOT EXISTS reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER,
        room_id INTEGER,
        check_in TEXT,
        check_out TEXT,
        total REAL,
        consecutivo INTEGER,
        FOREIGN KEY(client_id) REFERENCES clients(id),
        FOREIGN KEY(room_id) REFERENCES rooms(id)
    )''')
    # Poblar habitaciones si está vacío
    c.execute('SELECT COUNT(*) FROM rooms')
    if c.fetchone()[0] == 0:
        c.executemany('INSERT INTO rooms (type, price, features, image) VALUES (?, ?, ?, ?)', [
            ('Suite Ecológica', 350000, 'Vista al lago, cama king, baño privado, wifi, desayuno incluido', 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80'),
            ('Habitación Familiar', 250000, '2 camas dobles, baño privado, wifi, desayuno incluido', 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=400&q=80'),
            ('Habitación Individual', 180000, 'Cama sencilla, baño privado, wifi, desayuno incluido', 'https://images.unsplash.com/photo-1519710164239-da123dc03ef4?auto=format&fit=crop&w=400&q=80')
        ])
    conn.commit()
    conn.close()

init_db()

def get_rooms():
    conn = get_db()
    rooms = conn.execute('SELECT id, type, price, features, image FROM rooms').fetchall()
    conn.close()
    return rooms

def make_reservation(name, email, room_id, check_in, check_out):
    conn = get_db()
    c = conn.cursor()
    # Insertar cliente si no existe
    c.execute('SELECT id FROM clients WHERE email = ?', (email,))
    client = c.fetchone()
    if client:
        client_id = client['id']
    else:
        c.execute('INSERT INTO clients (name, email, phone) VALUES (?, ?, ?)', (name, email, ''))
        client_id = c.lastrowid
    # Calcular consecutivo
    c.execute('SELECT COUNT(*) FROM reservations WHERE client_id = ?', (client_id,))
    consecutivo = c.fetchone()[0] + 1
    # Calcular total
    c.execute('SELECT price FROM rooms WHERE id = ?', (room_id,))
    room = c.fetchone()
    if not room:
        conn.close()
        return None, "Habitación no encontrada"
    price = room['price']
    days = (datetime.strptime(check_out, '%Y-%m-%d') - datetime.strptime(check_in, '%Y-%m-%d')).days
    total = price * days
    # Insertar reserva
    c.execute('INSERT INTO reservations (client_id, room_id, check_in, check_out, total, consecutivo) VALUES (?, ?, ?, ?, ?, ?)',
              (client_id, room_id, check_in, check_out, total, consecutivo))
    conn.commit()
    invoice = f"Factura\nCliente: {name}\nEmail: {email}\nHabitación: {room_id}\nCheck-in: {check_in}\nCheck-out: {check_out}\nTotal: ${total:.2f}"
    email_content = f"Reserva confirmada\nConsecutivo de reserva: {consecutivo}\n{invoice}"
    conn.close()
    return {'email': email_content, 'invoice': invoice, 'consecutivo': consecutivo, 'total': total, 'name': name, 'email': email, 'room_id': room_id, 'check_in': check_in, 'check_out': check_out}, None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/rooms')
def view_rooms():
    rooms = get_rooms()
    return render_template('rooms.html', rooms=rooms)

@app.route('/reserve', methods=['GET', 'POST'])
def reserve():
    try:
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            room_id = int(request.form['room_id'])
            check_in = request.form['check_in']
            check_out = request.form['check_out']
            
            result, error = make_reservation(name, email, room_id, check_in, check_out)
            if error:
                flash(error, 'error')
                return redirect(url_for('reserve'))
            else:
                flash("Reserva confirmada! Revise su correo para la confirmación.", 'success')
                # Redirigir a pago
                return redirect(url_for('pago', consecutivo=result['consecutivo'], total=result['total'], name=result['name'], email=result['email'], room_id=result['room_id'], check_in=result['check_in'], check_out=result['check_out']))
        
        rooms = get_rooms()
        return render_template('reserve.html', rooms=rooms)
    except Exception as e:
        return f"Error inesperado: {e}", 500

@app.route('/pago', methods=['GET', 'POST'])
def pago():
    consecutivo = request.args.get('consecutivo')
    total = request.args.get('total')
    name = request.args.get('name')
    email = request.args.get('email')
    room_id = request.args.get('room_id')
    check_in = request.args.get('check_in')
    check_out = request.args.get('check_out')
    if request.method == 'POST':
        flash('Pago realizado con éxito. Factura generada.')
        return render_template('confirmation.html', reservation={
            'consecutivo': consecutivo,
            'total': total,
            'name': name,
            'email': email,
            'room_id': room_id,
            'check_in': check_in,
            'check_out': check_out
        })
    return render_template('pago.html', consecutivo=consecutivo, total=total, name=name, email=email, room_id=room_id, check_in=check_in, check_out=check_out)

if __name__ == '__main__':
    app.run(debug=True)
