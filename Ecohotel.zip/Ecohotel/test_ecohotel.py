
import unittest
from ecohotel import app
import matplotlib.pyplot as plt

class EcohotelTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        self.results = []

    def test_home(self):
        response = self.app.get('/')
        expected = 200
        actual = response.status_code
        print(f"Home: esperado={expected}, real={actual}")
    passed = (actual == expected)
    import unittest
    from ecohotel import app
    import matplotlib.pyplot as plt

    class EcohotelTestCase(unittest.TestCase):
        def setUp(self):
            self.app = app.test_client()
            self.app.testing = True
            self.results = []

        def test_home(self):
            response = self.app.get('/')
            expected = 200
            actual = response.status_code
            print(f"Home: esperado={expected}, real={actual}")
            passed = (actual == expected)
            self.results.append(('test_home', passed))
            self.assertEqual(actual, expected)

        def test_rooms(self):
            response = self.app.get('/rooms')
            expected = 200
            actual = response.status_code
            print(f"Rooms: esperado={expected}, real={actual}")
            passed = (actual == expected)
            self.results.append(('test_rooms', passed))
            self.assertEqual(actual, expected)

        def test_reserve_invalid_email(self):
            response = self.app.post('/reserve', data={
                'name': 'Test',
                'email': '',
                'room_id': 1,
                'check_in': '2025-08-26',
                'check_out': '2025-08-28'
            })
            expected = True
            actual = b'error' in response.data
            print(f"Reserva email inválido: esperado={expected}, real={actual}")
            passed = (actual == expected)
            self.results.append(('test_reserve_invalid_email', passed))
            self.assertEqual(actual, expected)

        def test_reserve_valid(self):
            response = self.app.post('/reserve', data={
                'name': 'Test',
                'email': 'test@example.com',
                'room_id': 1,
                'check_in': '2025-08-26',
                'check_out': '2025-08-28'
            }, follow_redirects=True)
            expected = True
            actual = b'Reserva confirmada' in response.data
            print(f"Reserva válida: esperado={expected}, real={actual}")
            passed = (actual == expected)
            self.results.append(('test_reserve_valid', passed))
            self.assertEqual(actual, expected)

        def test_admin_panel(self):
            response = self.app.get('/admin/reservas')
            expected_status = 200
            actual_status = response.status_code
            expected_text = True
            actual_text = b'Reservas Realizadas' in response.data
            print(f"Admin panel status: esperado={expected_status}, real={actual_status}")
            print(f"Admin panel texto: esperado={expected_text}, real={actual_text}")
            passed_status = (actual_status == expected_status)
            passed_text = (actual_text == expected_text)
            self.results.append(('test_admin_panel_status', passed_status))
            self.results.append(('test_admin_panel_text', passed_text))
            self.assertEqual(actual_status, expected_status)
            self.assertEqual(actual_text, expected_text)

    def plot_results(all_results):
        names = [name for name, passed in all_results]
        values = [1 if passed else 0 for name, passed in all_results]
        colors = ['green' if v else 'red' for v in values]
        plt.figure(figsize=(10,5))
        bars = plt.bar(names, values, color=colors)
        plt.ylim(0,1.2)
        plt.ylabel('Resultado')
        plt.title('Resultados de Pruebas Automatizadas')
        plt.xticks(rotation=30)
        plt.tight_layout()
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor='green', label='Prueba exitosa'),
                          Patch(facecolor='red', label='Prueba fallida')]
        plt.legend(handles=legend_elements, loc='upper right')
        for bar, passed in zip(bars, values):
            label = 'OK' if passed else 'Fallo'
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height()+0.05, label,
                     ha='center', va='bottom', fontsize=10, fontweight='bold', color=bar.get_facecolor())
        plt.show()

    if __name__ == '__main__':
        suite = unittest.TestLoader().loadTestsFromTestCase(EcohotelTestCase)
        runner = unittest.TextTestRunner()
        result = runner.run(suite)
        all_results = []
        for test in suite:
            if hasattr(test, 'results'):
                all_results.extend(test.results)
        plot_results(all_results)
